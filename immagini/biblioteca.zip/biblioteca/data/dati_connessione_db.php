<?php 
    $db_servername = "localhost";
	$db_name = "biblioteca";
	$db_username = "root";
	$db_password = "";
?>