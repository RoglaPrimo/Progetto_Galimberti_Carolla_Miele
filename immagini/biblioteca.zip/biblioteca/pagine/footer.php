<?php 
    echo '<div class="footer">';
    echo '<em>"Biblioteca Online"</em>, esempio di sito dinamico in PHP realizzato da Francesco Tormene';
    echo '</div>';
?>